"""
Email Notification System
Sends email alerts for data conflicts
"""
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import logging
from datetime import datetime
import json
import secrets
import socket

logger = logging.getLogger(__name__)

# ------------------------------
# Email Configuration - UPDATED WITH APP PASSWORD
# ------------------------------
class EmailConfig:
    """Email configuration"""
    SMTP_SERVER = "smtp.gmail.com"
    SMTP_PORT_TLS = 587
    SMTP_PORT_SSL = 465
    SENDER_EMAIL = "wonder208230@gmail.com"
    # App Password: ggkz celt oodd hbqn (remove spaces)
    SENDER_PASSWORD = "ggkzceltooddhbqn"  # ← USE THIS EXACT PASSWORD (no spaces)
    ADMIN_EMAIL = "wonder208230@gmail.com"  # primary recipient


# ------------------------------
# Send conflict email (IMPROVED VERSION)
# ------------------------------
def send_conflict_email(conflicts):
    """
    Send email notification about data conflicts
    """
    if not conflicts:
        logger.info("No conflicts to report via email.")
        return False

    try:
        # Prepare email
        msg = MIMEMultipart('alternative')
        msg['Subject'] = f"🚨 Data Sync Conflicts Detected - {datetime.now().strftime('%Y-%m-%d %H:%M')}"
        msg['From'] = EmailConfig.SENDER_EMAIL
        msg['To'] = EmailConfig.ADMIN_EMAIL
        
        # Add CC for testing (optional)
        # msg['Cc'] = "another@email.com"
        
        # Summarize conflicts
        conflict_count = len(conflicts)
        
        # Group conflicts by type
        conflict_details = []
        for c in conflicts[:5]:  # Show first 5 conflicts only
            conflict_type = c.get('conflict_type', 'unknown')
            primary_data = c.get('primary_data', {})
            secondary_data = c.get('secondary_data', {})
            
            # Create a readable summary
            summary = f"- Table: {c.get('table', 'unknown')}, "
            summary += f"ID: {c.get('primary_key', 'N/A')}, "
            summary += f"DB: {c.get('secondary_db', 'unknown')}, "
            summary += f"Type: {conflict_type}"
            
            # Show data differences if available
            if isinstance(primary_data, dict) and isinstance(secondary_data, dict):
                diff_fields = []
                for key in primary_data:
                    if key in secondary_data and primary_data[key] != secondary_data[key]:
                        diff_fields.append(f"{key}: '{primary_data[key]}' vs '{secondary_data[key]}'")
                
                if diff_fields:
                    summary += f" (Diff: {', '.join(diff_fields[:2])})"
            
            conflict_details.append(summary)
        
        conflict_summary = "\n".join(conflict_details)
        if conflict_count > 5:
            conflict_summary += f"\n... and {conflict_count - 5} more conflicts"

        # Generate resolution link
        resolution_token = secrets.token_urlsafe(16)
        resolution_url = f"http://127.0.0.1:5000/conflicts"

        # HTML content
        html_content = f"""
        <html>
        <body style="font-family: Arial, sans-serif; line-height: 1.6;">
            <div style="max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #ddd; border-radius: 5px;">
                <h2 style="color: #dc3545;">⚠️ Data Sync Conflicts Alert</h2>
                <p>Detected <strong style="color: #dc3545;">{conflict_count} conflicts</strong> during latest sync.</p>
                
                <div style="background-color: #f8f9fa; padding: 15px; border-radius: 5px; margin: 15px 0;">
                    <h4 style="margin-top: 0;">Conflict Summary:</h4>
                    <pre style="white-space: pre-wrap; font-family: monospace; font-size: 12px; margin: 0;">{conflict_summary}</pre>
                </div>
                
                <p>Please resolve conflicts using the link below:</p>
                <p style="text-align: center; margin: 25px 0;">
                    <a href="{resolution_url}" style="background-color: #007bff; color: white; padding: 10px 20px; 
                    text-decoration: none; border-radius: 5px; display: inline-block;">
                        Go to Conflict Resolution Panel
                    </a>
                </p>
                
                <div style="margin-top: 30px; padding-top: 15px; border-top: 1px solid #eee; font-size: 12px; color: #666;">
                    <p>Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>
                    <p>System: Multi-Database Sync System</p>
                </div>
            </div>
        </body>
        </html>
        """

        # Plain text fallback
        text_content = f"""
        DATA SYNC CONFLICTS ALERT
        
        Detected {conflict_count} conflicts during latest sync.
        
        Conflict summary:
        {conflict_summary}
        
        Resolve conflicts here: {resolution_url}
        
        Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
        System: Multi-Database Sync System
        """

        msg.attach(MIMEText(text_content, 'plain'))
        msg.attach(MIMEText(html_content, 'html'))

        # Set socket timeout to 15 seconds
        socket.setdefaulttimeout(15)

        logger.info(f"📧 Attempting to send email for {conflict_count} conflicts...")
        logger.info(f"Using SMTP: {EmailConfig.SMTP_SERVER}:{EmailConfig.SMTP_PORT_TLS}")
        logger.info(f"From: {EmailConfig.SENDER_EMAIL}")
        logger.info(f"To: {EmailConfig.ADMIN_EMAIL}")
        
        # Try TLS first (preferred)
        try:
            logger.info("Trying TLS connection...")
            server = smtplib.SMTP(EmailConfig.SMTP_SERVER, EmailConfig.SMTP_PORT_TLS, timeout=15)
            server.starttls()
            logger.info("TLS started, attempting login...")
            server.login(EmailConfig.SENDER_EMAIL, EmailConfig.SENDER_PASSWORD)
            logger.info("Login successful, sending email...")
            server.send_message(msg)
            server.quit()
            logger.info(f"✅ Conflict email sent successfully via TLS to {EmailConfig.ADMIN_EMAIL}")
            return True
            
        except Exception as tls_error:
            logger.warning(f"TLS failed: {str(tls_error)[:100]}")
            logger.warning("Trying SSL as fallback...")
            
            # Fallback to SSL
            try:
                server = smtplib.SMTP_SSL(EmailConfig.SMTP_SERVER, EmailConfig.SMTP_PORT_SSL, timeout=15)
                server.login(EmailConfig.SENDER_EMAIL, EmailConfig.SENDER_PASSWORD)
                server.send_message(msg)
                server.quit()
                logger.info(f"✅ Conflict email sent successfully via SSL to {EmailConfig.ADMIN_EMAIL}")
                return True
                
            except Exception as ssl_error:
                logger.error(f"❌ Both TLS and SSL failed: {str(ssl_error)[:100]}")
                # Log the actual error for debugging
                import traceback
                logger.error(f"Full error: {traceback.format_exc()}")
                
                # For testing, log the email content
                logger.info("📧 Email content (for testing):")
                logger.info(f"Subject: {msg['Subject']}")
                logger.info(f"To: {msg['To']}")
                logger.info(f"Content preview: {text_content[:200]}...")
                return False

    except Exception as e:
        logger.error(f"❌ Failed to send conflict email: {str(e)}")
        import traceback
        logger.error(f"Full traceback: {traceback.format_exc()}")
        return False


# ------------------------------
# Send test email (for debugging)
# ------------------------------
def send_test_email():
    """Send a test email to verify email configuration"""
    logger.info("📧 Sending test email...")
    try:
        msg = MIMEMultipart('alternative')
        msg['Subject'] = f"✅ Test Email - Multi-DB Sync System - {datetime.now().strftime('%Y-%m-%d %H:%M')}"
        msg['From'] = EmailConfig.SENDER_EMAIL
        msg['To'] = EmailConfig.ADMIN_EMAIL

        html_content = f"""
        <html>
        <body style="font-family: Arial, sans-serif;">
            <h2>✅ Test Email Successful</h2>
            <p>This is a test email from the Multi-DB Sync System.</p>
            <p>Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>
            <p>If you receive this, email notifications are working correctly!</p>
        </body>
        </html>
        """

        msg.attach(MIMEText(html_content, 'html'))

        socket.setdefaulttimeout(15)
        
        logger.info("Trying TLS for test email...")
        # Try TLS
        try:
            server = smtplib.SMTP(EmailConfig.SMTP_SERVER, EmailConfig.SMTP_PORT_TLS, timeout=15)
            server.starttls()
            server.login(EmailConfig.SENDER_EMAIL, EmailConfig.SENDER_PASSWORD)
            server.send_message(msg)
            server.quit()
            logger.info("✅ Test email sent successfully via TLS")
            return True
        except Exception as tls_err:
            logger.warning(f"TLS failed for test: {str(tls_err)[:100]}")
            # Try SSL
            try:
                server = smtplib.SMTP_SSL(EmailConfig.SMTP_SERVER, EmailConfig.SMTP_PORT_SSL, timeout=15)
                server.login(EmailConfig.SENDER_EMAIL, EmailConfig.SENDER_PASSWORD)
                server.send_message(msg)
                server.quit()
                logger.info("✅ Test email sent successfully via SSL")
                return True
            except Exception as ssl_err:
                logger.error(f"❌ Test email failed: {str(ssl_err)}")
                return False
                
    except Exception as e:
        logger.error(f"❌ Test email failed: {str(e)}")
        import traceback
        logger.error(f"Full traceback: {traceback.format_exc()}")
        return False
"""
Conflict Detection Module - FIXED VERSION
Automatically detects conflicts between databases and sends email alerts
"""
import logging
from datetime import datetime
from app import db
from app.emailer import send_conflict_email
import sqlite3
import json
import os

logger = logging.getLogger(__name__)

class ConflictDetector:
    def __init__(self, app):
        self.app = app
        self.basedir = app.config.get('BASEDIR')
        self.databases = {
            'primary': 'primary.db',
            'mysql': 'mysql_sim.db', 
            'postgresql': 'postgres_sim.db'
        }
        logger.info(f"Conflict detector initialized with base dir: {self.basedir}")

    def detect_data_conflicts(self):
        """Detect conflicts between primary and secondary databases"""
        conflicts = []
        logger.info("Starting conflict detection...")

        # List of tables to check for conflicts
        tables = ['users', 'authors', 'sections', 'books', 'borrow_records']

        for table in tables:
            try:
                logger.debug(f"Checking table: {table}")
                
                # Get primary database data
                primary_data = self._get_table_data(table, 'primary')
                logger.debug(f"Primary {table}: {len(primary_data)} records")
                
                if not primary_data:
                    logger.warning(f"No data found in primary database for table {table}")
                    continue

                # Compare with each secondary database
                for db_type in ['mysql', 'postgresql']:
                    db_path = os.path.join(self.basedir, self.databases[db_type])
                    if not os.path.exists(db_path):
                        logger.warning(f"Database {db_type} not found at {db_path}")
                        continue
                    
                    secondary_data = self._get_table_data(table, db_type)
                    logger.debug(f"{db_type} {table}: {len(secondary_data)} records")
                    
                    # Check for missing records in secondary
                    for record_id, primary_record in primary_data.items():
                        if record_id not in secondary_data:
                            # Record exists in primary but not in secondary
                            conflict = {
                                'table': table,
                                'primary_key': record_id,
                                'primary_data': primary_record,
                                'secondary_data': None,
                                'secondary_db': db_type,
                                'detected_at': datetime.utcnow().isoformat(),
                                'status': 'missing_in_secondary',
                                'conflict_type': 'missing_record'
                            }
                            conflicts.append(conflict)
                            logger.warning(f"Missing record in {db_type}.{table}.{record_id}")
                    
                    # Check for missing records in primary
                    for record_id, secondary_record in secondary_data.items():
                        if record_id not in primary_data:
                            # Record exists in secondary but not in primary
                            conflict = {
                                'table': table,
                                'primary_key': record_id,
                                'primary_data': None,
                                'secondary_data': secondary_record,
                                'secondary_db': db_type,
                                'detected_at': datetime.utcnow().isoformat(),
                                'status': 'missing_in_primary',
                                'conflict_type': 'missing_record'
                            }
                            conflicts.append(conflict)
                            logger.warning(f"Missing record in primary.{table}.{record_id}")
                    
                    # Check for data mismatches
                    for record_id in set(primary_data.keys()) & set(secondary_data.keys()):
                        primary_record = primary_data[record_id]
                        secondary_record = secondary_data[record_id]
                        
                        # Compare records excluding sync-related fields
                        conflict_found = False
                        differences = {}
                        
                        for key in set(primary_record.keys()) | set(secondary_record.keys()):
                            if key in ['sync_version', 'last_updated', 'created_at']:
                                continue
                                
                            primary_value = primary_record.get(key)
                            secondary_value = secondary_record.get(key)
                            
                            # Handle None comparisons
                            if primary_value is None and secondary_value is None:
                                continue
                            elif primary_value is None or secondary_value is None:
                                conflict_found = True
                                differences[key] = {
                                    'primary': primary_value,
                                    'secondary': secondary_value
                                }
                            elif str(primary_value) != str(secondary_value):
                                conflict_found = True
                                differences[key] = {
                                    'primary': primary_value,
                                    'secondary': secondary_value
                                }
                        
                        if conflict_found:
                            conflict = {
                                'table': table,
                                'primary_key': record_id,
                                'primary_data': primary_record,
                                'secondary_data': secondary_record,
                                'secondary_db': db_type,
                                'detected_at': datetime.utcnow().isoformat(),
                                'status': 'data_mismatch',
                                'conflict_type': 'data_conflict',
                                'differences': differences
                            }
                            conflicts.append(conflict)
                            logger.warning(f"Data mismatch in {table}.{record_id} between primary and {db_type}")

            except Exception as e:
                logger.error(f"Error detecting conflicts in {table}: {str(e)}")
                import traceback
                traceback.print_exc()

        logger.info(f"Total conflicts detected: {len(conflicts)}")
        return conflicts

    def _get_table_data(self, table_name, db_type):
        """Get all data from a table as a dict keyed by primary key"""
        db_path = os.path.join(self.basedir, self.databases[db_type])
        data = {}
        
        if not os.path.exists(db_path):
            logger.error(f"Database file not found: {db_path}")
            return data
        
        try:
            conn = sqlite3.connect(db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            # Check if table exists
            cursor.execute(f"SELECT name FROM sqlite_master WHERE type='table' AND name='{table_name}'")
            if not cursor.fetchone():
                logger.warning(f"Table {table_name} does not exist in {db_type}")
                conn.close()
                return data
            
            # Get primary key column
            cursor.execute(f"PRAGMA table_info({table_name})")
            columns_info = cursor.fetchall()
            
            pk_column = 'id'  # Default assumption
            for col_info in columns_info:
                if col_info[5] == 1:  # Column 5 is pk flag in sqlite
                    pk_column = col_info[1]
                    break
            
            # Get all rows
            cursor.execute(f"SELECT * FROM {table_name}")
            rows = cursor.fetchall()
            
            for row in rows:
                row_dict = {}
                for idx, col in enumerate(cursor.description):
                    value = row[idx]
                    # Convert datetime objects to strings
                    if isinstance(value, datetime):
                        row_dict[col[0]] = value.isoformat()
                    else:
                        row_dict[col[0]] = value
                
                if pk_column in row_dict:
                    data[row_dict[pk_column]] = row_dict
            
            conn.close()
            
        except Exception as e:
            logger.error(f"Error reading {db_type}.{table_name}: {str(e)}")
            import traceback
            traceback.print_exc()
        
        return data

    def check_and_notify(self):
        """Main method to detect conflicts, store them, and send email notifications"""
        try:
            conflicts = self.detect_data_conflicts()

            if conflicts:
                logger.info(f"Detected {len(conflicts)} conflicts")
                
                # Store conflicts first (so they appear in web interface)
                stored = self._store_conflicts(conflicts)
                if stored:
                    logger.info(f"Stored {len(conflicts)} conflicts in database")
                
                # Send email notification
                email_sent = send_conflict_email(conflicts)
                if email_sent:
                    logger.info(f"Conflict email sent for {len(conflicts)} conflicts")
                else:
                    logger.warning("Email notification failed, but conflicts are stored in database")
                
                return len(conflicts)
            else:
                logger.info("No conflicts detected")
                return 0

        except Exception as e:
            logger.error(f"Error in conflict detection: {str(e)}")
            import traceback
            traceback.print_exc()
            return 0

    def _store_conflicts(self, conflicts):
        """Store conflicts in the database for resolution UI"""
        try:
            db_path = os.path.join(self.basedir, self.databases['primary'])
            conn = sqlite3.connect(db_path)
            cursor = conn.cursor()
            
            # Ensure data_conflicts table exists
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS data_conflicts (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    table_name TEXT NOT NULL,
                    record_id INTEGER NOT NULL,
                    database_source TEXT NOT NULL,
                    conflict_data TEXT NOT NULL,
                    detected_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    resolved BOOLEAN DEFAULT 0,
                    resolved_by INTEGER,
                    resolved_at TIMESTAMP,
                    resolution_action TEXT
                )
            ''')
            
            stored_count = 0
            for conflict in conflicts:
                # Check if conflict already exists
                cursor.execute('''
                    SELECT id FROM data_conflicts 
                    WHERE table_name = ? AND record_id = ? AND database_source = ? AND resolved = 0
                ''', (conflict['table'], conflict['primary_key'], conflict['secondary_db']))
                
                existing = cursor.fetchone()
                
                if not existing:
                    cursor.execute('''
                        INSERT INTO data_conflicts 
                        (table_name, record_id, database_source, conflict_data, detected_at, resolved)
                        VALUES (?, ?, ?, ?, ?, ?)
                    ''', (
                        conflict['table'],
                        conflict['primary_key'],
                        conflict['secondary_db'],
                        json.dumps(conflict, default=str),  # Use default=str for serialization
                        conflict['detected_at'],
                        False
                    ))
                    stored_count += 1
                    logger.debug(f"Stored conflict: {conflict['table']}.{conflict['primary_key']}")
            
            conn.commit()
            conn.close()
            logger.info(f"Stored {stored_count} new conflicts in database")
            return True
            
        except Exception as e:
            logger.error(f"Error storing conflicts: {str(e)}")
            import traceback
            traceback.print_exc()
            return False


def init_detector(app):
    """Initialize and return a conflict detector instance"""
    from app import db
    app.config['BASEDIR'] = app.config.get('BASEDIR', 
        os.path.abspath(os.path.dirname(os.path.dirname(__file__))))
    detector = ConflictDetector(app)
    return detector
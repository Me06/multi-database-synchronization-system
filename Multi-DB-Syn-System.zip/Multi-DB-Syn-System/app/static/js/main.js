// main.js - Fixed version
// --- SYNC ---
function triggerSync() {
    fetch('/api/sync/manual', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        }
    })
    .then(res => res.json())
    .then(data => {
        alert(data.message || 'Sync completed');
        if (data.error) {
            alert('Error: ' + data.error);
        }
    })
    .catch(err => {
        console.error('Sync failed:', err);
        alert('Sync failed: ' + err.message);
    });
}

// --- CONFLICTS ---
async function loadConflicts() {
    try {
        const res = await fetch('/api/conflicts');
        const data = await res.json();

        const tbody = document.getElementById('conflicts-table');
        if (!tbody) return;
        
        tbody.innerHTML = '';

        if (!data.conflicts || data.conflicts.length === 0) {
            tbody.innerHTML = '<tr><td colspan="7">No unresolved conflicts</td></tr>';
            return;
        }

        data.conflicts.forEach(conflict => {
            const tr = document.createElement('tr');

            // Parse conflict data
            const conflictData = conflict.data || {};
            const primaryData = conflictData.primary_data || {};
            const secondaryData = conflictData.secondary_data || {};
            
            // Create editable view
            let editableHtml = '';
            if (primaryData && typeof primaryData === 'object') {
                for (const [key, value] of Object.entries(primaryData)) {
                    if (key === 'id' || key === 'sync_version' || key === 'last_updated') continue;
                    editableHtml += `
                        <div class="field-row">
                            <label>${key}:</label>
                            <input type="text" name="${key}" value="${value || ''}" 
                                   placeholder="Primary: ${value}">
                            ${secondaryData && secondaryData[key] !== undefined ? 
                              `<small class="secondary-value">Secondary: ${secondaryData[key]}</small>` : ''}
                        </div>`;
                }
            }

            tr.innerHTML = `
                <td>${conflict.id}</td>
                <td>${conflict.table}</td>
                <td>${conflict.record_id}</td>
                <td>${conflict.source}</td>
                <td>${new Date(conflict.detected_at).toLocaleString()}</td>
                <td>
                    <div class="editable-conflict" id="conflict-${conflict.id}">
                        ${editableHtml}
                    </div>
                </td>
                <td>
                    <button onclick="mergeConflict(${conflict.id}, 'primary', true)" class="btn-primary">Keep Primary</button>
                    <button onclick="mergeConflict(${conflict.id}, 'secondary')" class="btn-secondary">Keep Secondary</button>
                    <button onclick="resolveConflict(${conflict.id})" class="btn-resolve">Mark Resolved</button>
                </td>
            `;
            tbody.appendChild(tr);
        });
    } catch (error) {
        console.error('Error loading conflicts:', error);
        alert('Failed to load conflicts');
    }
}

async function mergeConflict(id, strategy, useEdited = false) {
    try {
        let payload = null;
        
        if (useEdited) {
            // Collect edited inputs
            const conflictDiv = document.getElementById(`conflict-${id}`);
            if (!conflictDiv) {
                alert('Conflict data not found');
                return;
            }
            
            const inputs = conflictDiv.querySelectorAll('input');
            payload = { edited_data: {} };
            
            inputs.forEach(input => {
                if (input.value && input.name) {
                    payload.edited_data[input.name] = input.value;
                }
            });
            
            if (Object.keys(payload.edited_data).length === 0) {
                alert('No changes detected. Using original primary data.');
                payload = null;
            }
        }

        const options = {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' }
        };
        
        if (payload) {
            options.body = JSON.stringify(payload);
        }
        
        const url = `/api/conflicts/merge/${id}?strategy=${strategy}`;
        const res = await fetch(url, options);
        const data = await res.json();
        
        if (data.error) {
            alert('Error: ' + data.error);
        } else {
            alert(data.message || 'Conflict resolved successfully');
            loadConflicts();
        }
    } catch (error) {
        console.error('Error merging conflict:', error);
        alert('Merge failed: ' + error.message);
    }
}

async function resolveConflict(conflictId) {
    if (!confirm('Mark this conflict as resolved?')) return;
    
    try {
        const res = await fetch(`/api/conflicts/resolve/${conflictId}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' }
        });
        const data = await res.json();
        
        if (data.error) {
            alert('Error: ' + data.error);
        } else {
            alert(data.message || 'Conflict marked as resolved');
            loadConflicts();
        }
    } catch (error) {
        console.error('Error resolving conflict:', error);
        alert('Failed to resolve conflict');
    }
}

function resolveAllConflicts(strategy) {
    if (!confirm(`Resolve all conflicts using ${strategy} strategy?`)) return;
    
    fetch(`/api/conflicts/resolve-all?strategy=${strategy}`, { 
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
    })
    .then(res => res.json())
    .then(data => {
        if (data.error) {
            alert('Error: ' + data.error);
        } else {
            alert(data.message || 'All conflicts resolved');
            loadConflicts();
        }
    })
    .catch(err => {
        console.error('Error resolving all conflicts:', err);
        alert('Failed to resolve all conflicts');
    });
}

// --- DATA BROWSER ---
async function loadTables() {
    try {
        const res = await fetch("/api/tables");
        const data = await res.json();
        const select = document.getElementById("table-select");
        
        if (!select) return;
        
        select.innerHTML = '<option value="">-- Select Table --</option>';
        
        if (data.tables && data.tables.length > 0) {
            data.tables.forEach(t => {
                const opt = document.createElement("option");
                opt.value = t;
                opt.textContent = t;
                select.appendChild(opt);
            });
        }
    } catch (error) {
        console.error('Error loading tables:', error);
    }
}

async function loadTableData(table, page = 1) {
    try {
        const res = await fetch(`/api/table-data?table=${table}&page=${page}`);
        const data = await res.json();
        const container = document.getElementById("table-data");
        
        if (!container) return;
        
        container.innerHTML = "";
        
        if (data.error) {
            container.textContent = "Error: " + data.error;
            return;
        }
        
        if (!data.rows || data.rows.length === 0) {
            container.textContent = "No data found.";
            return;
        }
        
        const tableEl = document.createElement("table");
        tableEl.className = "data-table";
        const thead = document.createElement("thead");
        const tbody = document.createElement("tbody");
        
        // Table headers
        const headerRow = document.createElement("tr");
        Object.keys(data.rows[0]).forEach(col => {
            const th = document.createElement("th");
            th.textContent = col;
            headerRow.appendChild(th);
        });
        thead.appendChild(headerRow);
        
        // Table rows
        data.rows.forEach(row => {
            const tr = document.createElement("tr");
            Object.values(row).forEach(val => {
                const td = document.createElement("td");
                td.textContent = val === null ? 'NULL' : val;
                tr.appendChild(td);
            });
            tbody.appendChild(tr);
        });
        
        tableEl.appendChild(thead);
        tableEl.appendChild(tbody);
        container.appendChild(tableEl);
        
        // Add pagination if needed
        if (data.total > data.per_page) {
            const pagination = document.createElement("div");
            pagination.className = "pagination";
            
            const totalPages = Math.ceil(data.total / data.per_page);
            for (let i = 1; i <= Math.min(totalPages, 10); i++) {
                const btn = document.createElement("button");
                btn.textContent = i;
                btn.className = i === page ? "active" : "";
                btn.onclick = () => loadTableData(table, i);
                pagination.appendChild(btn);
            }
            
            container.appendChild(pagination);
        }
    } catch (error) {
        console.error('Error loading table data:', error);
        const container = document.getElementById("table-data");
        if (container) {
            container.textContent = "Error loading data";
        }
    }
}

// --- INSERT DATA ---
async function insertData(table, formData) {
    try {
        const res = await fetch(`/api/insert`, {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ table, data: formData })
        });
        const result = await res.json();
        
        if (result.error) {
            alert('Insert failed: ' + result.error);
            return false;
        } else {
            alert(result.message || 'Data inserted successfully');
            return true;
        }
    } catch (error) {
        console.error('Error inserting data:', error);
        alert('Insert failed: ' + error.message);
        return false;
    }
}

// --- SQL QUERY RUNNER ---
async function runQuery(sql) {
    try {
        const res = await fetch('/api/query/execute', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({query: sql})
        });
        const data = await res.json();
        return data;
    } catch (err) {
        console.error('Query execution error:', err);
        return { error: 'Query failed: ' + err.message };
    }
}

// --- DOM READY ---
document.addEventListener("DOMContentLoaded", () => {
    // Initialize table selector
    const tableSelect = document.getElementById("table-select");
    if (tableSelect) {
        loadTables();
        tableSelect.addEventListener("change", () => {
            if (tableSelect.value) {
                loadTableData(tableSelect.value);
            }
        });
    }
    
    // Initialize conflicts table
    if (document.getElementById('conflicts-table')) {
        loadConflicts();
    }
    
    // Initialize query runner
    const queryBtn = document.getElementById('run-query-btn');
    if (queryBtn) {
        queryBtn.addEventListener('click', async () => {
            const sqlInput = document.getElementById('sql-query');
            const resultDiv = document.getElementById('query-result');
            
            if (!sqlInput || !resultDiv) return;
            
            const sql = sqlInput.value.trim();
            if (!sql) {
                resultDiv.innerHTML = '<div class="error">Please enter a SQL query</div>';
                return;
            }
            
            resultDiv.innerHTML = '<div class="loading">Executing query...</div>';
            
            const result = await runQuery(sql);
            
            if (result.error) {
                resultDiv.innerHTML = `<div class="error">${result.error}</div>`;
            } else if (result.data && result.data.length > 0) {
                // Build results table
                let html = `<div class="success">${result.message}</div>`;
                html += '<table class="result-table">';
                html += '<thead><tr>';
                
                // Headers
                Object.keys(result.data[0]).forEach(col => {
                    html += `<th>${col}</th>`;
                });
                html += '</tr></thead><tbody>';
                
                // Rows
                result.data.forEach(row => {
                    html += '<tr>';
                    Object.values(row).forEach(val => {
                        html += `<td>${val === null ? 'NULL' : val}</td>`;
                    });
                    html += '</tr>';
                });
                
                html += '</tbody></table>';
                resultDiv.innerHTML = html;
            } else {
                resultDiv.innerHTML = `<div class="info">${result.message || 'No results found'}</div>`;
            }
        });
    }
});

// --- ADMIN FUNCTIONS ---
function generateReport() {
    fetch('/api/stats')
    .then(res => res.json())
    .then(data => {
        const resultDiv = document.getElementById('admin-result');
        if (data.error) {
            resultDiv.innerHTML = `<div class="error">${data.error}</div>`;
        } else {
            let html = '<h4>System Report</h4>';
            html += `<p>Last Sync: ${data.sync.last_sync ? new Date(data.sync.last_sync).toLocaleString() : 'Never'}</p>`;
            html += `<p>Unresolved Conflicts: ${data.conflicts.unresolved}</p>`;
            html += `<p>Total Users: ${data.users.total}</p>`;
            resultDiv.innerHTML = html;
        }
    })
    .catch(err => {
        console.error('Error generating report:', err);
        document.getElementById('admin-result').innerHTML = '<div class="error">Failed to generate report</div>';
    });
}

function clearConflicts() {
    if (!confirm('Clear all resolved conflicts? This cannot be undone.')) return;
    
    // Note: You need to add this endpoint to routes.py
    fetch('/api/conflicts/clear-resolved', { method: 'POST' })
    .then(res => res.json())
    .then(data => {
        if (data.error) {
            alert('Error: ' + data.error);
        } else {
            alert(data.message || 'Resolved conflicts cleared');
            if (document.getElementById('conflicts-table')) {
                loadConflicts();
            }
        }
    })
    .catch(err => {
        console.error('Error clearing conflicts:', err);
        alert('Failed to clear conflicts');
    });
}
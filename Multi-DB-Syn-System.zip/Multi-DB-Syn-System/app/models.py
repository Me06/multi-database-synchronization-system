from app import db
from flask_login import UserMixin
from datetime import datetime
import hashlib


# ------------------------------
# User Model
# ------------------------------
class User(UserMixin, db.Model):
    __tablename__ = 'users'

    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)

    role = db.Column(db.String(20), default='user')

    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_login = db.Column(db.DateTime)
    last_updated = db.Column(
        db.DateTime,
        default=datetime.utcnow,
        onupdate=datetime.utcnow
    )

    # Permissions
    can_manage_users = db.Column(db.Boolean, default=False)
    can_resolve_conflicts = db.Column(db.Boolean, default=False)
    can_view_reports = db.Column(db.Boolean, default=True)

    # Sync
    sync_version = db.Column(db.Integer, default=0)

    def set_password(self, password: str):
        self.password_hash = hashlib.sha256(password.encode()).hexdigest()

    def check_password(self, password: str) -> bool:
        return self.password_hash == hashlib.sha256(password.encode()).hexdigest()

    def __repr__(self):
        return f"<User {self.username}>"


# ------------------------------
# Author Model
# ------------------------------
class Author(db.Model):
    __tablename__ = 'authors'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    nationality = db.Column(db.String(50))
    birth_year = db.Column(db.Integer)
    biography = db.Column(db.Text)

    last_updated = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    sync_version = db.Column(db.Integer, default=0)


# ------------------------------
# Section Model
# ------------------------------
class Section(db.Model):
    __tablename__ = 'sections'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text)
    floor = db.Column(db.Integer)
    room_number = db.Column(db.String(20))

    last_updated = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    sync_version = db.Column(db.Integer, default=0)


# ------------------------------
# Book Model
# ------------------------------
class Book(db.Model):
    __tablename__ = 'books'

    id = db.Column(db.Integer, primary_key=True)
    isbn = db.Column(db.String(13), unique=True, nullable=False)
    title = db.Column(db.String(200), nullable=False)

    author_id = db.Column(db.Integer, db.ForeignKey('authors.id'))
    section_id = db.Column(db.Integer, db.ForeignKey('sections.id'))

    published_year = db.Column(db.Integer)
    publisher = db.Column(db.String(100))
    copies_available = db.Column(db.Integer, default=1)
    price = db.Column(db.Float)

    last_updated = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    sync_version = db.Column(db.Integer, default=0)


# ------------------------------
# Borrow Record Model
# ------------------------------
class BorrowRecord(db.Model):
    __tablename__ = 'borrow_records'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    book_id = db.Column(db.Integer, db.ForeignKey('books.id'))

    borrow_date = db.Column(db.DateTime, default=datetime.utcnow)
    due_date = db.Column(db.DateTime)
    return_date = db.Column(db.DateTime)

    status = db.Column(db.String(20), default='borrowed')
    fine_amount = db.Column(db.Float, default=0.0)

    last_updated = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    sync_version = db.Column(db.Integer, default=0)


# ------------------------------
# Sync Metadata Model
# ------------------------------
class SyncMetadata(db.Model):
    __tablename__ = 'sync_metadata'

    id = db.Column(db.Integer, primary_key=True)
    sync_timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    changes_synced = db.Column(db.Integer, default=0)
    conflicts_detected = db.Column(db.Integer, default=0)
    status = db.Column(db.String(20), default='completed')


# ------------------------------
# Data Conflict Model
# ------------------------------
class DataConflict(db.Model):
    __tablename__ = 'data_conflicts'

    id = db.Column(db.Integer, primary_key=True)
    table_name = db.Column(db.String(50), nullable=False)
    record_id = db.Column(db.Integer, nullable=False)
    database_source = db.Column(db.String(20), nullable=False)
    conflict_data = db.Column(db.Text, nullable=False)

    detected_at = db.Column(db.DateTime, default=datetime.utcnow)
    resolved = db.Column(db.Boolean, default=False)

    resolved_by = db.Column(db.Integer, db.ForeignKey('users.id'))
    resolved_at = db.Column(db.DateTime)
    resolution_action = db.Column(db.String(20))

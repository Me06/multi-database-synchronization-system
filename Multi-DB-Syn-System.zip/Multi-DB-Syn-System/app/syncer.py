import os
import logging
import sqlite3
import json
import time
from datetime import datetime
from threading import Thread, Lock

logger = logging.getLogger(__name__)

class RealTimeSyncer:
    def __init__(self, app):
        self.app = app
        self.running = False
        self.sync_thread = None
        self.sync_lock = Lock()
        self.last_sync_time = {}
        self.conflict_count = 0
        self.initialized = False

        # Project root
        self.basedir = app.config.get('BASEDIR', 
            os.path.abspath(os.path.dirname(os.path.dirname(__file__))))

        # Database paths
        self.databases = {
            'primary': os.path.join(self.basedir, 'primary.db'),
            'mysql': os.path.join(self.basedir, 'mysql_sim.db'),
            'postgresql': os.path.join(self.basedir, 'postgres_sim.db')
        }

    def start(self):
        """Start real-time synchronization"""
        if self.running:
            return

        self.running = True
        self.sync_thread = Thread(target=self._sync_loop, daemon=True)
        self.sync_thread.start()
        logger.info("Real-time sync started")

    def _sync_loop(self):
        """Main synchronization loop"""
        time.sleep(5)  # Wait for app to fully start
        self.initialized = True
        
        # Only create tables, don't copy data initially (to preserve pre-created conflicts)
        logger.info("Performing initial setup - creating tables only")
        self.create_tables_only()
        
        # Now detect conflicts (the pre-created ones should be detected)
        logger.info("Performing initial conflict detection...")
        from app.detector import ConflictDetector
        detector = ConflictDetector(self.app)
        conflict_count = detector.check_and_notify()
        logger.info(f"Initial conflict detection found {conflict_count} conflicts")

        while self.running:
            try:
                with self.app.app_context():
                    self.perform_sync()
            except Exception as e:
                logger.error(f"Sync loop error: {e}")
            time.sleep(30)  # Check every 30 seconds
    
    def create_tables_only(self):
        """Create tables in secondary databases WITHOUT copying data"""
        logger.info("Creating tables in secondary databases (preserving existing data)")
        try:
            tables = ['users', 'authors', 'sections', 'books', 'borrow_records',
                      'sync_metadata', 'data_conflicts']

            for target_db in ['mysql', 'postgresql']:
                target_path = self.databases[target_db]
                
                # Only create tables if they don't exist (don't overwrite data)
                if not os.path.exists(target_path):
                    self.create_tables_in_target(target_path, tables)
                    logger.info(f"Created tables in {target_db}")
                else:
                    # Check if tables exist, create any missing ones
                    self.ensure_tables_exist(target_path, tables)
                    logger.info(f"Verified tables exist in {target_db}")

            logger.info("Table creation completed - preserving existing data")
            
        except Exception as e:
            logger.error(f"Initial setup failed: {e}")

    def ensure_tables_exist(self, db_path, tables):
        """Create any missing tables without dropping existing ones"""
        try:
            primary_conn = sqlite3.connect(self.databases['primary'])
            primary_cursor = primary_conn.cursor()
            target_conn = sqlite3.connect(db_path)
            target_cursor = target_conn.cursor()

            for table in tables:
                # Check if table exists in target
                target_cursor.execute(f"SELECT name FROM sqlite_master WHERE type='table' AND name='{table}'")
                if not target_cursor.fetchone():
                    # Table doesn't exist, create it
                    primary_cursor.execute(
                        f"SELECT sql FROM sqlite_master WHERE type='table' AND name='{table}'"
                    )
                    create_sql = primary_cursor.fetchone()
                    if create_sql:
                        target_cursor.execute(create_sql[0])
                        logger.debug(f"Created missing table '{table}' in {db_path}")

            target_conn.commit()
            target_conn.close()
            primary_conn.close()
        except Exception as e:
            logger.error(f"Error ensuring tables exist in {db_path}: {e}")

    def _ensure_primary_tables(self):
        """Ensure primary database has all required tables"""
        try:
            conn = sqlite3.connect(self.databases['primary'])
            cursor = conn.cursor()
            
            # Check and create tables if they don't exist
            from app.models import User, Author, Section, Book, BorrowRecord, SyncMetadata, DataConflict
            from app import db
            
            with self.app.app_context():
                db.create_all()
            
            conn.close()
        except Exception as e:
            logger.error(f"Error ensuring primary tables: {e}")

    def create_tables_in_target(self, target_db_path, tables):
        """Create tables in target database"""
        try:
            primary_conn = sqlite3.connect(self.databases['primary'])
            primary_cursor = primary_conn.cursor()
            target_conn = sqlite3.connect(target_db_path)
            target_cursor = target_conn.cursor()

            for table in tables:
                primary_cursor.execute(
                    f"SELECT sql FROM sqlite_master WHERE type='table' AND name='{table}'"
                )
                create_sql = primary_cursor.fetchone()
                if create_sql:
                    # Only drop if table exists
                    target_cursor.execute(f"DROP TABLE IF EXISTS {table}")
                    target_cursor.execute(create_sql[0])
                    logger.debug(f"Created table '{table}' in {target_db_path}")

            target_conn.commit()
            target_conn.close()
            primary_conn.close()
        except Exception as e:
            logger.error(f"Error creating tables in {target_db_path}: {e}")

    def copy_data_from_primary(self, target_db_path, target_db_name, tables):
        """Copy data from primary to target database - Used for manual sync operations"""
        try:
            primary_conn = sqlite3.connect(self.databases['primary'])
            primary_conn.row_factory = sqlite3.Row
            primary_cursor = primary_conn.cursor()

            target_conn = sqlite3.connect(target_db_path)
            target_cursor = target_conn.cursor()

            total_records = 0
            for table in tables:
                primary_cursor.execute(f"SELECT * FROM {table}")
                rows = primary_cursor.fetchall()
                if rows:
                    col_names = [desc[0] for desc in primary_cursor.description]
                    placeholders = ', '.join(['?'] * len(col_names))
                    col_names_str = ', '.join(col_names)
                    
                    # Delete existing data
                    target_cursor.execute(f"DELETE FROM {table}")
                    
                    # Insert new data
                    insert_sql = f"INSERT INTO {table} ({col_names_str}) VALUES ({placeholders})"
                    for row in rows:
                        target_cursor.execute(insert_sql, tuple(row))
                    total_records += len(rows)
                    logger.debug(f"Copied {len(rows)} records to '{table}' in {target_db_name}")

            target_conn.commit()
            target_conn.close()
            primary_conn.close()
            logger.info(f"Copied {total_records} total records to {target_db_name}")
        except Exception as e:
            logger.error(f"Error copying data to {target_db_name}: {e}")

    def perform_sync(self):
        """Perform synchronization between databases"""
        if not self.initialized:
            logger.info("Waiting for database initialization")
            return

        try:
            start_time = datetime.now()
            logger.info(f"Starting sync at {start_time.strftime('%H:%M:%S')}")
            
            # First, run conflict detection
            from app.detector import ConflictDetector
            detector = ConflictDetector(self.app)
            conflict_count = detector.check_and_notify()
            
            # Then perform sync (only sync changes, not full overwrite)
            tables = ['users', 'authors', 'sections', 'books', 'borrow_records']
            total_changes = 0
            new_conflicts = []

            for table in tables:
                changes, conflicts = self.sync_table_incremental(table)
                total_changes += changes
                new_conflicts.extend(conflicts)

            self.update_sync_metadata(total_changes, conflict_count)

            elapsed = (datetime.now() - start_time).total_seconds()
            logger.info(f"Sync completed: {total_changes} changes, {conflict_count} conflicts in {elapsed:.2f}s")
            
            return {
                'changes': total_changes,
                'conflicts': conflict_count,
                'time': elapsed
            }
            
        except Exception as e:
            logger.error(f"Sync failed: {e}")
            return {'error': str(e)}

    def sync_table_incremental(self, table_name):
        """Sync only changed records (incremental sync)"""
        changes = 0
        conflicts = []

        try:
            primary_conn = sqlite3.connect(self.databases['primary'])
            primary_conn.row_factory = sqlite3.Row
            primary_cursor = primary_conn.cursor()
            
            # Get last sync time for this table
            last_sync = self.last_sync_time.get(table_name, datetime.min)

            # Check what columns exist in the table
            primary_cursor.execute(f"PRAGMA table_info({table_name})")
            columns_info = primary_cursor.fetchall()
            column_names = [info[1] for info in columns_info]
            
            # Check if table has timestamp columns
            has_last_updated = 'last_updated' in column_names
            has_created_at = 'created_at' in column_names
            
            # Build query based on available columns
            if has_last_updated:
                # Use last_updated column if it exists
                primary_cursor.execute(f"""
                    SELECT * FROM {table_name} 
                    WHERE last_updated >= ?
                    ORDER BY id
                """, (last_sync.isoformat(),))
            elif has_created_at:
                # Use created_at column if last_updated doesn't exist
                primary_cursor.execute(f"""
                    SELECT * FROM {table_name} 
                    WHERE created_at >= ?
                    ORDER BY id
                """, (last_sync.isoformat(),))
            else:
                # No timestamp columns, get all records
                primary_cursor.execute(f"SELECT * FROM {table_name} ORDER BY id")
            
            rows = primary_cursor.fetchall()
            
            if not rows:
                primary_conn.close()
                return changes, conflicts

            for db_name in ['mysql', 'postgresql']:
                db_path = self.databases[db_name]
                if not os.path.exists(db_path):
                    logger.warning(f"{db_name} database not found: {db_path}")
                    continue

                try:
                    sec_conn = sqlite3.connect(db_path)
                    sec_cursor = sec_conn.cursor()

                    for row in rows:
                        record_id = row['id']
                        record_data = tuple(row)
                        
                        # Check if record exists
                        sec_cursor.execute(f"SELECT * FROM {table_name} WHERE id = ?", (record_id,))
                        existing = sec_cursor.fetchone()
                        
                        if existing:
                            # Only update if data is different
                            should_update = False
                            for i, col in enumerate(column_names):
                                if col != 'id' and record_data[i] != existing[i]:
                                    should_update = True
                                    break
                            
                            if should_update:
                                # Update existing record
                                set_parts = []
                                values = []
                                for i, col in enumerate(column_names):
                                    if col != 'id':
                                        set_parts.append(f"{col} = ?")
                                        values.append(record_data[i])
                                
                                values.append(record_id)
                                update_sql = f"UPDATE {table_name} SET {', '.join(set_parts)} WHERE id = ?"
                                sec_cursor.execute(update_sql, values)
                                changes += 1
                        else:
                            # Insert new record
                            columns = ', '.join(column_names)
                            placeholders = ', '.join(['?'] * len(column_names))
                            insert_sql = f"INSERT INTO {table_name} ({columns}) VALUES ({placeholders})"
                            sec_cursor.execute(insert_sql, record_data)
                            changes += 1

                    sec_conn.commit()
                    sec_conn.close()
                    
                except Exception as e:
                    logger.error(f"Error syncing to {db_name}: {e}")

            primary_conn.close()
            self.last_sync_time[table_name] = datetime.now()

        except Exception as e:
            logger.error(f"Error syncing table {table_name}: {e}")

        return changes, conflicts

    def update_sync_metadata(self, changes_count, conflicts_count):
        """Update synchronization metadata"""
        try:
            conn = sqlite3.connect(self.databases['primary'])
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO sync_metadata (sync_timestamp, changes_synced, conflicts_detected, status)
                VALUES (?, ?, ?, ?)
            ''', (datetime.now().isoformat(), changes_count, conflicts_count, 'completed'))
            conn.commit()
            conn.close()
        except Exception as e:
            logger.error(f"Error updating metadata: {e}")

    def force_sync(self):
        """Force immediate synchronization with conflict detection"""
        with self.sync_lock:
            logger.info("Forcing immediate synchronization")
            try:
                # First detect conflicts
                from app.detector import ConflictDetector
                detector = ConflictDetector(self.app)
                conflict_count = detector.check_and_notify()
                
                # Then perform incremental sync
                result = self.perform_sync()
                result['conflicts'] = conflict_count  # Update with actual count
                
                logger.info(f"Force sync completed: {result}")
                return result
            except Exception as e:
                logger.error(f"Force sync failed: {e}")
                return {'error': str(e)}

    def get_sync_status(self):
        """Get current sync status"""
        status = {
            'running': self.running,
            'initialized': self.initialized,
            'last_sync_times': {k: v.isoformat() for k, v in self.last_sync_time.items()},
            'total_conflicts': self.conflict_count,
            'database_status': {}
        }

        for db_name, db_path in self.databases.items():
            if os.path.exists(db_path):
                try:
                    conn = sqlite3.connect(db_path)
                    cursor = conn.cursor()
                    
                    # Get table count
                    cursor.execute("SELECT COUNT(*) FROM sqlite_master WHERE type='table'")
                    table_count = cursor.fetchone()[0]

                    # Get all tables
                    cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")
                    tables = cursor.fetchall()
                    
                    total_records = 0
                    for (table_name,) in tables:
                        try:
                            cursor.execute(f"SELECT COUNT(*) FROM {table_name}")
                            count_result = cursor.fetchone()
                            if count_result:
                                total_records += count_result[0]
                        except:
                            pass

                    conn.close()
                    
                    status['database_status'][db_name] = {
                        'online': True,
                        'tables': table_count,
                        'records': total_records,
                        'path': db_path
                    }
                    
                except Exception as e:
                    status['database_status'][db_name] = {'online': False, 'error': str(e)}
            else:
                status['database_status'][db_name] = {'online': False, 'error': 'File not found'}

        return status


# Global syncer instance
real_time_syncer: RealTimeSyncer | None = None

def init_syncer(app):
    """Initialize and start the real-time syncer"""
    global real_time_syncer
    if real_time_syncer is None:
        real_time_syncer = RealTimeSyncer(app)
        real_time_syncer.start()
    return real_time_syncer
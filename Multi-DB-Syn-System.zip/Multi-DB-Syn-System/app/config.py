"""
Configuration settings for the Multi-DB Sync System
"""
import os
from datetime import timedelta

class Config:
    """Base configuration"""
    # Flask settings
    SECRET_KEY = os.environ.get('SECRET_KEY', 'dev-secret-key-change-in-production')
    
    # Primary Database (SQLite)
    SQLALCHEMY_DATABASE_URI = 'sqlite:///primary.db'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    
    # MySQL Database Configuration
    MYSQL_DATABASE_URI = os.environ.get('MYSQL_DATABASE_URI', 'mysql://user:password@localhost/multi_db_sync')
    MYSQL_DATABASE_HOST = os.environ.get('MYSQL_HOST', 'localhost')
    MYSQL_DATABASE_PORT = int(os.environ.get('MYSQL_PORT', 3306))
    MYSQL_DATABASE_NAME = os.environ.get('MYSQL_DB_NAME', 'multi_db_sync')
    MYSQL_DATABASE_USER = os.environ.get('MYSQL_USER', 'root')
    MYSQL_DATABASE_PASSWORD = os.environ.get('MYSQL_PASSWORD', 'password')
    
    # PostgreSQL Database Configuration
    POSTGRES_DATABASE_URI = os.environ.get('POSTGRES_DATABASE_URI', 'postgresql://user:password@localhost/multi_db_sync')
    POSTGRES_DATABASE_HOST = os.environ.get('POSTGRES_HOST', 'localhost')
    POSTGRES_DATABASE_PORT = int(os.environ.get('POSTGRES_PORT', 5432))
    POSTGRES_DATABASE_NAME = os.environ.get('POSTGRES_DB_NAME', 'multi_db_sync')
    POSTGRES_DATABASE_USER = os.environ.get('POSTGRES_USER', 'postgres')
    POSTGRES_DATABASE_PASSWORD = os.environ.get('POSTGRES_PASSWORD', 'password')
    
    # Database simulation for demo
    USE_SIMULATED_DBS = True
    
    # Email settings
    MAIL_SERVER = 'smtp.gmail.com'
    MAIL_PORT = 587
    MAIL_USE_TLS = True
    MAIL_USERNAME = 'wonder208230@gmail.com'
    MAIL_PASSWORD = 'xmpusgytuylvekju'
    MAIL_DEFAULT_SENDER = 'wonder208230@gmail.com'
    ADMIN_EMAIL = 'wonder208230@gmail.com'
    NOTIFICATION_EMAILS = ['wonder208230@gmail.com']
    
    # Sync settings
    SYNC_INTERVAL_MINUTES = 1
    SCHEDULED_SYNC_CRONTAB = '*/5 * * * *'  # Every 5 minutes
    REAL_TIME_SYNC_ENABLED = True
    SCHEDULED_SYNC_ENABLED = True
    MAX_SYNC_RETRIES = 3
    SYNC_BATCH_SIZE = 100
    
    # Sync modes
    SYNC_MODE_REALTIME = 'realtime'
    SYNC_MODE_SCHEDULED = 'scheduled'
    SYNC_MODE_MANUAL = 'manual'
    
    # Application settings
    DEMO_MODE = True
    AUTO_GENERATE_CONFLICTS = True
    CONFLICT_GENERATION_INTERVAL = 300  # seconds
    
    # Security settings
    SESSION_COOKIE_SECURE = False
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = 'Lax'
    
    # Mobile access
    MOBILE_ACCESS_ENABLED = True
    MOBILE_TOKEN_EXPIRY = 3600  # seconds
    
    # JWT settings
    JWT_SECRET_KEY = SECRET_KEY
    JWT_ACCESS_TOKEN_EXPIRES = timedelta(hours=1)
    
    # Logging
    LOG_LEVEL = 'INFO'
    LOG_FILE = 'app.log'
    
    # Reports
    REPORT_GENERATION_INTERVAL = 'daily'
    REPORT_RETENTION_DAYS = 30
    
    # API
    API_RATE_LIMIT = '100 per minute'
    
    # Crontab jobs for scheduled tasks
    CRONJOBS = [
        ('*/5 * * * *', 'app.syncer.scheduled_sync_job', ['--mode', 'scheduled']),
        ('0 2 * * *', 'app.syncer.generate_daily_report', ['--type', 'daily'])
    ]


class DevelopmentConfig(Config):
    DEBUG = True
    DEMO_MODE = True
    USE_SIMULATED_DBS = True
    SYNC_INTERVAL_MINUTES = 1
    SCHEDULED_SYNC_CRONTAB = '*/2 * * * *'


class ProductionConfig(Config):
    DEBUG = False
    DEMO_MODE = False
    USE_SIMULATED_DBS = False
    SYNC_INTERVAL_MINUTES = 5
    SCHEDULED_SYNC_CRONTAB = '*/10 * * * *'
    SESSION_COOKIE_SECURE = True
    MAIL_SERVER = 'smtp.gmail.com'  # Set production mail server


class TestingConfig(Config):
    TESTING = True
    DEBUG = True
    USE_SIMULATED_DBS = True
    SQLALCHEMY_DATABASE_URI = 'sqlite:///:memory:'
    REAL_TIME_SYNC_ENABLED = False


# Configuration dictionary
config = {
    'development': DevelopmentConfig,
    'production': ProductionConfig,
    'testing': TestingConfig,
    'default': DevelopmentConfig
}


# Helper to get DB config without creating app multiple times
def get_database_config(db_type, app=None):
    """Return database config dictionary"""
    if not app:
        from app import create_app
        app = create_app()

    if db_type == 'mysql':
        return {
            'uri': app.config['MYSQL_DATABASE_URI'],
            'host': app.config['MYSQL_DATABASE_HOST'],
            'port': app.config['MYSQL_DATABASE_PORT'],
            'database': app.config['MYSQL_DATABASE_NAME'],
            'user': app.config['MYSQL_DATABASE_USER'],
            'password': app.config['MYSQL_DATABASE_PASSWORD']
        }
    elif db_type == 'postgresql':
        return {
            'uri': app.config['POSTGRES_DATABASE_URI'],
            'host': app.config['POSTGRES_DATABASE_HOST'],
            'port': app.config['POSTGRES_DATABASE_PORT'],
            'database': app.config['POSTGRES_DATABASE_NAME'],
            'user': app.config['POSTGRES_DATABASE_USER'],
            'password': app.config['POSTGRES_DATABASE_PASSWORD']
        }
    else:  # sqlite
        return {
            'uri': app.config['SQLALCHEMY_DATABASE_URI'],
            'file': 'primary.db'
        }

from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_required, current_user
import sqlite3, os, hashlib, logging

logger = logging.getLogger(__name__)
admin_bp = Blueprint("admin", __name__)

BASE_DIR = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))
DB_PATH = os.path.join(BASE_DIR, "primary.db")

@admin_bp.route("/")
@login_required
def panel():
    if current_user.role != "admin":
        flash("Access denied", "danger")
        return redirect(url_for("routes.dashboard"))
    return render_template("admin.html")

@admin_bp.route("/register", methods=["GET", "POST"])
@login_required
def register():
    if current_user.role != "admin":
        flash("Access denied", "danger")
        return redirect(url_for("routes.dashboard"))

    if request.method == "POST":
        username = request.form["username"]
        email = request.form["email"]
        password = hashlib.sha256(request.form["password"].encode()).hexdigest()

        conn = sqlite3.connect(DB_PATH)
        cur = conn.cursor()
        cur.execute(
            "INSERT INTO users (username,email,password_hash,role) VALUES (?,?,?,?)",
            (username, email, password, "user")
        )
        conn.commit()
        conn.close()

        flash("User created", "success")
        logger.info(f"Admin created user {username}")

    return render_template("register.html")

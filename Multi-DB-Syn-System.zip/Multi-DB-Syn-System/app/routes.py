"""
Main Routes for Multi-DB Sync System
"""
from flask import Blueprint, render_template, jsonify, request, abort, current_app
from flask_login import login_required, current_user
from app import db
from app.models import DataConflict, SyncMetadata, User
import json
import sqlite3
from functools import wraps
import os
import logging
from datetime import datetime

logger = logging.getLogger(__name__)

routes_bp = Blueprint("routes", __name__)
api_bp = Blueprint("api", __name__)

def admin_required(f):
    @wraps(f)
    @login_required
    def wrapper(*args, **kwargs):
        if current_user.role != "admin":
            abort(403)
        return f(*args, **kwargs)
    return wrapper

@routes_bp.route("/")
def index():
    return render_template("index.html")

@routes_bp.route("/dashboard")
@login_required
def dashboard():
    return render_template("dashboard.html")

@routes_bp.route("/conflicts")
@login_required
def conflicts_page():
    return render_template("conflicts.html")

@routes_bp.route("/query")
@login_required
def query_page():
    return render_template("query.html")

@routes_bp.route("/data-browser")
@login_required
@admin_required
def data_browser():
    return render_template("data_browser.html")

@routes_bp.route("/admin")
@login_required
@admin_required
def admin_panel():
    return render_template("admin.html")

@api_bp.route("/conflicts")
@login_required
def get_conflicts():
    page = max(int(request.args.get("page", 1)), 1)
    per_page = max(int(request.args.get("per_page", 20)), 1)

    query = DataConflict.query.filter_by(resolved=False)
    total = query.count()

    conflicts = (
        query.order_by(DataConflict.detected_at.desc())
        .offset((page - 1) * per_page)
        .limit(per_page)
        .all()
    )

    data = []
    for c in conflicts:
        try:
            conflict_data = json.loads(c.conflict_data) if c.conflict_data else {}
        except:
            conflict_data = {}
            
        data.append({
            "id": c.id,
            "table": c.table_name,
            "record_id": c.record_id,
            "source": c.database_source,
            "detected_at": c.detected_at.isoformat() if c.detected_at else None,
            "resolved": c.resolved,
            "data": conflict_data
        })

    return jsonify({"total": total, "conflicts": data})

@api_bp.route("/conflicts/resolve/<int:conflict_id>", methods=["POST"])
@login_required
@admin_required
def resolve_conflict(conflict_id):
    conflict = DataConflict.query.get_or_404(conflict_id)
    
    try:
        conflict.resolved = True
        conflict.resolved_by = current_user.id
        conflict.resolved_at = datetime.utcnow()
        conflict.resolution_action = 'marked_resolved'
        
        db.session.commit()
        return jsonify({
            "message": f"Conflict {conflict_id} marked as resolved",
            "conflict_id": conflict_id
        })
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error resolving conflict: {str(e)}")
        return jsonify({"error": str(e)}), 500

@api_bp.route("/conflicts/clear-resolved", methods=["POST"])
@login_required
@admin_required
def clear_resolved_conflicts():
    try:
        resolved_count = DataConflict.query.filter_by(resolved=True).count()
        DataConflict.query.filter_by(resolved=True).delete()
        db.session.commit()
        return jsonify({
            "message": f"Cleared {resolved_count} resolved conflicts",
            "cleared": resolved_count
        })
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error clearing resolved conflicts: {str(e)}")
        return jsonify({"error": str(e)}), 500

@api_bp.route("/sync/manual", methods=["POST"])
@login_required
@admin_required
def manual_sync():
    syncer = getattr(current_app, "real_time_syncer", None)
    if not syncer:
        return jsonify({"error": "Syncer not initialized"}), 500
    
    try:
        logger.info("Manual sync triggered by admin")
        result = syncer.force_sync()
        
        if 'error' in result:
            return jsonify({"error": result['error']}), 500
        
        return jsonify({
            "message": "Manual sync completed",
            "details": result
        })
        
    except Exception as e:
        logger.error(f"Manual sync failed: {str(e)}")
        return jsonify({"error": str(e)}), 500

@api_bp.route("/sync/status", methods=["GET"])
@login_required
def sync_status():
    syncer = getattr(current_app, "real_time_syncer", None)
    if not syncer:
        return jsonify({"error": "Syncer not initialized"}), 500
    
    try:
        status = syncer.get_sync_status()
        return jsonify(status)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@api_bp.route("/conflicts/merge/<int:conflict_id>", methods=["POST"])
@login_required
@admin_required
def merge_conflict(conflict_id):
    data = request.json or {}
    strategy = request.args.get("strategy", "primary")
    
    conflict = DataConflict.query.get_or_404(conflict_id)
    
    try:
        conflict_data = json.loads(conflict.conflict_data)
        table = conflict.table_name
        record_id = conflict.record_id
        db_type = conflict.database_source
        
        if strategy == "primary":
            success = _apply_primary_to_secondary(table, record_id, db_type)
            if success:
                conflict.resolved = True
                conflict.resolved_by = current_user.id
                conflict.resolved_at = datetime.utcnow()
                conflict.resolution_action = 'keep_primary'
                db.session.commit()
                return jsonify({"message": f"Conflict {conflict_id} resolved (kept primary data)"})
            else:
                return jsonify({"error": "Failed to apply primary data"}), 500
                
        elif strategy == "secondary":
            success = _apply_secondary_to_primary(table, record_id, db_type, conflict_data)
            if success:
                conflict.resolved = True
                conflict.resolved_by = current_user.id
                conflict.resolved_at = datetime.utcnow()
                conflict.resolution_action = 'keep_secondary'
                db.session.commit()
                return jsonify({"message": f"Conflict {conflict_id} resolved (kept secondary data)"})
            else:
                return jsonify({"error": "Failed to apply secondary data"}), 500
                
        elif strategy == "custom" and data.get('edited_data'):
            success = _apply_custom_data(table, record_id, db_type, data['edited_data'])
            if success:
                conflict.resolved = True
                conflict.resolved_by = current_user.id
                conflict.resolved_at = datetime.utcnow()
                conflict.resolution_action = 'custom_resolution'
                db.session.commit()
                return jsonify({"message": f"Conflict {conflict_id} resolved (custom data)"})
            else:
                return jsonify({"error": "Failed to apply custom data"}), 500
                
        else:
            return jsonify({"error": "Invalid strategy or missing data"}), 400
            
    except Exception as e:
        logger.error(f"Error merging conflict {conflict_id}: {str(e)}")
        return jsonify({"error": str(e)}), 500

@api_bp.route("/conflicts/resolve-all", methods=["POST"])
@login_required
@admin_required
def resolve_all_conflicts():
    strategy = request.args.get("strategy", "primary")
    
    try:
        unresolved = DataConflict.query.filter_by(resolved=False).all()
        resolved_count = 0
        
        for conflict in unresolved:
            if strategy == "primary":
                success = _apply_primary_to_secondary(conflict.table_name, conflict.record_id, conflict.database_source)
            elif strategy == "secondary":
                conflict_data = json.loads(conflict.conflict_data)
                success = _apply_secondary_to_primary(conflict.table_name, conflict.record_id, conflict.database_source, conflict_data)
            else:
                success = True
                
            if success:
                conflict.resolved = True
                conflict.resolved_by = current_user.id
                conflict.resolved_at = datetime.utcnow()
                conflict.resolution_action = f'batch_{strategy}'
                resolved_count += 1
        
        db.session.commit()
        return jsonify({
            "message": f"Resolved {resolved_count} conflicts using {strategy} strategy",
            "resolved": resolved_count
        })
        
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error resolving all conflicts: {str(e)}")
        return jsonify({"error": str(e)}), 500

@api_bp.route("/tables")
@login_required
@admin_required
def list_tables():
    syncer = getattr(current_app, "real_time_syncer", None)
    if not syncer:
        return jsonify({"error": "Syncer not initialized"}), 500
    
    db_path = syncer.databases.get("primary")
    if not db_path:
        return jsonify({"error": "Primary database path not found"}), 500
    
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        cursor.execute("""
            SELECT name FROM sqlite_master 
            WHERE type='table' AND name NOT LIKE 'sqlite_%'
            ORDER BY name
        """)
        tables = [row[0] for row in cursor.fetchall()]
        conn.close()
        return jsonify({"tables": tables})
    except Exception as e:
        logger.error(f"Error listing tables: {str(e)}")
        return jsonify({"error": str(e)}), 500

@api_bp.route("/table-data")
@login_required
@admin_required
def table_data():
    table = request.args.get("table")
    page = int(request.args.get("page", 1))
    per_page = 20
    offset = (page - 1) * per_page

    if not table:
        return jsonify({"rows": [], "total": 0})

    syncer = getattr(current_app, "real_time_syncer", None)
    if not syncer:
        return jsonify({"error": "Syncer not initialized"}), 500
    
    db_path = syncer.databases.get("primary")
    if not db_path:
        return jsonify({"error": "Primary database path not found"}), 500
    
    try:
        conn = sqlite3.connect(db_path)
        conn.row_factory = sqlite3.Row
        
        cursor = conn.cursor()
        try:
            cursor.execute(f"SELECT COUNT(*) FROM {table}")
            total = cursor.fetchone()[0]
        except:
            total = 0
        
        cursor = conn.cursor()
        cursor.execute(f"SELECT * FROM {table} LIMIT ? OFFSET ?", (per_page, offset))
        rows = [dict(r) for r in cursor.fetchall()]
        conn.close()

        return jsonify({
            "rows": rows,
            "total": total,
            "page": page,
            "per_page": per_page
        })
        
    except Exception as e:
        logger.error(f"Error getting table data: {str(e)}")
        return jsonify({"error": str(e)}), 500

@api_bp.route("/insert", methods=["POST"])
@login_required
@admin_required
def insert_data():
    payload = request.json
    table = payload.get("table")
    data = payload.get("data") or payload

    if not table or not isinstance(data, dict):
        return jsonify({"error": "Invalid payload"}), 400

    syncer = getattr(current_app, "real_time_syncer", None)
    if not syncer:
        return jsonify({"error": "Syncer not initialized"}), 500
    
    db_path = syncer.databases.get("primary")
    if not db_path:
        return jsonify({"error": "Primary database path not found"}), 500
    
    conn = None
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()

        columns = ", ".join(data.keys())
        placeholders = ", ".join(["?"] * len(data))
        values = list(data.values())

        cursor.execute(f"INSERT INTO {table} ({columns}) VALUES ({placeholders})", values)
        conn.commit()
        
        syncer.force_sync()
        
        return jsonify({
            "message": f"Data inserted into {table}",
            "id": cursor.lastrowid
        })
        
    except Exception as e:
        logger.error(f"Error inserting data: {str(e)}")
        return jsonify({"error": str(e)}), 500
    finally:
        if conn:
            conn.close()

@api_bp.route("/query/execute", methods=["POST"])
@login_required
def execute_query():
    payload = request.json
    query = payload.get("query", "").strip()
    
    if not query:
        return jsonify({"error": "No query provided"}), 400
    
    query_lower = query.lower()
    if not query_lower.startswith(('select ', 'pragma ', 'explain ')):
        return jsonify({"error": "Only SELECT, PRAGMA, and EXPLAIN queries are allowed"}), 400
    
    syncer = getattr(current_app, "real_time_syncer", None)
    if not syncer:
        return jsonify({"error": "Syncer not initialized"}), 500
    
    db_path = syncer.databases.get("primary")
    if not db_path:
        return jsonify({"error": "Primary database path not found"}), 500
    
    try:
        conn = sqlite3.connect(db_path)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        cursor.execute(query)
        
        rows = [dict(r) for r in cursor.fetchall()]
        conn.close()
        
        return jsonify({
            "success": True,
            "message": f"Query executed successfully. Found {len(rows)} records.",
            "data": rows,
            "count": len(rows)
        })
            
    except sqlite3.Error as e:
        logger.error(f"SQL error executing query: {str(e)}")
        return jsonify({"error": f"SQL Error: {str(e)}"}), 500
    except Exception as e:
        logger.error(f"Error executing query: {str(e)}")
        return jsonify({"error": str(e)}), 500

@api_bp.route("/query/run", methods=["POST"])
@login_required
def run_query():
    return execute_query()

@api_bp.route("/stats")
@login_required
def get_stats():
    try:
        sync_stats = SyncMetadata.query.order_by(SyncMetadata.sync_timestamp.desc()).first()
        total_conflicts = DataConflict.query.count()
        unresolved_conflicts = DataConflict.query.filter_by(resolved=False).count()
        total_users = User.query.count()
        
        syncer = getattr(current_app, "real_time_syncer", None)
        syncer_status = syncer.get_sync_status() if syncer else {"error": "Syncer not available"}
        
        return jsonify({
            "sync": {
                "last_sync": sync_stats.sync_timestamp.isoformat() if sync_stats else None,
                "last_changes": sync_stats.changes_synced if sync_stats else 0,
                "last_conflicts": sync_stats.conflicts_detected if sync_stats else 0
            },
            "conflicts": {
                "total": total_conflicts,
                "unresolved": unresolved_conflicts,
                "resolved": total_conflicts - unresolved_conflicts
            },
            "users": {
                "total": total_users,
                "admins": User.query.filter_by(role='admin').count(),
                "regular": User.query.filter_by(role='user').count()
            },
            "syncer": syncer_status
        })
        
    except Exception as e:
        logger.error(f"Error getting stats: {str(e)}")
        return jsonify({"error": str(e)}), 500

def _apply_primary_to_secondary(table, record_id, db_type):
    try:
        app = current_app._get_current_object()
        basedir = app.config.get('BASEDIR', '.')
        
        primary_db_path = os.path.join(basedir, 'primary.db')
        conn = sqlite3.connect(primary_db_path)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        cursor.execute(f"SELECT * FROM {table} WHERE id = ?", (record_id,))
        primary_row = cursor.fetchone()
        conn.close()
        
        if not primary_row:
            logger.error(f"Record {table}.{record_id} not found in primary")
            return False
        
        secondary_db_path = os.path.join(basedir, f'{db_type}_sim.db')
        sec_conn = sqlite3.connect(secondary_db_path)
        sec_cursor = sec_conn.cursor()
        
        sec_cursor.execute(f"SELECT id FROM {table} WHERE id = ?", (record_id,))
        exists_in_secondary = sec_cursor.fetchone()
        
        if exists_in_secondary:
            primary_dict = dict(primary_row)
            set_parts = []
            values = []
            
            for key, value in primary_dict.items():
                if key != 'id':
                    set_parts.append(f"{key} = ?")
                    values.append(value)
            
            values.append(record_id)
            update_sql = f"UPDATE {table} SET {', '.join(set_parts)} WHERE id = ?"
            sec_cursor.execute(update_sql, values)
        else:
            primary_dict = dict(primary_row)
            columns = ', '.join(primary_dict.keys())
            placeholders = ', '.join(['?'] * len(primary_dict))
            values = list(primary_dict.values())
            
            insert_sql = f"INSERT INTO {table} ({columns}) VALUES ({placeholders})"
            sec_cursor.execute(insert_sql, values)
        
        sec_conn.commit()
        sec_conn.close()
        
        logger.info(f"Applied primary data to {db_type} for {table}.{record_id}")
        return True
        
    except Exception as e:
        logger.error(f"Error applying primary to secondary: {e}")
        return False

def _apply_secondary_to_primary(table, record_id, db_type, conflict_data):
    try:
        app = current_app._get_current_object()
        basedir = app.config.get('BASEDIR', '.')
        
        secondary_data = conflict_data.get('secondary_data')
        if not secondary_data:
            secondary_db_path = os.path.join(basedir, f'{db_type}_sim.db')
            sec_conn = sqlite3.connect(secondary_db_path)
            sec_cursor = sec_conn.cursor()
            sec_cursor.execute(f"SELECT * FROM {table} WHERE id = ?", (record_id,))
            secondary_row = sec_cursor.fetchone()
            sec_conn.close()
            
            if not secondary_row:
                logger.error(f"Record {table}.{record_id} not found in {db_type}")
                return False
            secondary_data = dict(secondary_row)
        
        primary_db_path = os.path.join(basedir, 'primary.db')
        conn = sqlite3.connect(primary_db_path)
        cursor = conn.cursor()
        
        cursor.execute(f"SELECT id FROM {table} WHERE id = ?", (record_id,))
        exists_in_primary = cursor.fetchone()
        
        if exists_in_primary:
            set_parts = []
            values = []
            
            for key, value in secondary_data.items():
                if key != 'id' and key not in ['sync_version', 'last_updated']:
                    set_parts.append(f"{key} = ?")
                    values.append(value)
            
            values.append(record_id)
            update_sql = f"UPDATE {table} SET {', '.join(set_parts)} WHERE id = ?"
            cursor.execute(update_sql, values)
        else:
            columns = ', '.join(secondary_data.keys())
            placeholders = ', '.join(['?'] * len(secondary_data))
            values = list(secondary_data.values())
            
            insert_sql = f"INSERT INTO {table} ({columns}) VALUES ({placeholders})"
            cursor.execute(insert_sql, values)
        
        conn.commit()
        conn.close()
        
        logger.info(f"Applied {db_type} data to primary for {table}.{record_id}")
        return True
        
    except Exception as e:
        logger.error(f"Error applying secondary to primary: {e}")
        return False

def _apply_custom_data(table, record_id, db_type, custom_data):
    try:
        success1 = _update_table_with_data('primary.db', table, record_id, custom_data)
        secondary_db = f'{db_type}_sim.db'
        success2 = _update_table_with_data(secondary_db, table, record_id, custom_data)
        
        return success1 and success2
        
    except Exception as e:
        logger.error(f"Error applying custom data: {e}")
        return False

def _update_table_with_data(db_file, table, record_id, data):
    try:
        app = current_app._get_current_object()
        basedir = app.config.get('BASEDIR', '.')
        db_path = os.path.join(basedir, db_file)
        
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        cursor.execute(f"SELECT id FROM {table} WHERE id = ?", (record_id,))
        exists = cursor.fetchone()
        
        if exists:
            set_parts = []
            values = []
            
            for key, value in data.items():
                if key != 'id':
                    set_parts.append(f"{key} = ?")
                    values.append(value)
            
            values.append(record_id)
            update_sql = f"UPDATE {table} SET {', '.join(set_parts)} WHERE id = ?"
            cursor.execute(update_sql, values)
        else:
            columns = ', '.join(data.keys())
            placeholders = ', '.join(['?'] * len(data))
            values = list(data.values())
            
            insert_sql = f"INSERT INTO {table} ({columns}) VALUES ({placeholders})"
            cursor.execute(insert_sql, values)
        
        conn.commit()
        conn.close()
        return True
        
    except Exception as e:
        logger.error(f"Error updating {db_file}.{table}.{record_id}: {e}")
        return False
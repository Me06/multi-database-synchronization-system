#!/usr/bin/env python3
"""
Start script for Multi-DB Sync System
Initializes databases, creates admin user, seeds test data, and starts the system
"""
import os
import sys
import sqlite3
import hashlib
import logging
import time
from datetime import datetime, timedelta
import json
import random

# Add project root to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

logger = logging.getLogger(__name__)

def delete_old_databases():
    """Delete old database files if they exist"""
    db_files = ['primary.db', 'mysql_sim.db', 'postgres_sim.db']
    
    for db_file in db_files:
        if os.path.exists(db_file):
            try:
                os.remove(db_file)
                logger.info(f"Deleted old database: {db_file}")
            except Exception as e:
                logger.error(f"Error deleting {db_file}: {e}")

def create_admin_user():
    """Create admin user in primary database"""
    try:
        conn = sqlite3.connect('primary.db')
        cursor = conn.cursor()
        
        # Check if admin already exists
        cursor.execute("SELECT id FROM users WHERE username = 'admin'")
        admin_exists = cursor.fetchone()
        
        if not admin_exists:
            password_hash = hashlib.sha256("admin123".encode()).hexdigest()
            cursor.execute('''
                INSERT INTO users (username, email, password_hash, role, created_at, 
                can_manage_users, can_resolve_conflicts, can_view_reports, sync_version)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', ('admin', 'admin@example.com', password_hash, 'admin', 
                  datetime.utcnow().isoformat(), 1, 1, 1, 0))
            
            conn.commit()
            logger.info("✅ Admin user created: admin / admin123")
        else:
            logger.info("✅ Admin user already exists")
            
        conn.close()
        
    except Exception as e:
        logger.error(f"Error creating admin user: {e}")

def create_test_users():
    """Create test users with conflicts"""
    users = [
        # Format: (username, email, password_hash, role, can_manage_users, can_resolve_conflicts, can_view_reports)
        ('alice', 'alice@example.com', hashlib.sha256('alice123'.encode()).hexdigest(), 'user', 0, 0, 1),
        ('bob', 'bob@example.com', hashlib.sha256('bob123'.encode()).hexdigest(), 'user', 0, 1, 1),
        ('charlie', 'charlie@example.com', hashlib.sha256('charlie123'.encode()).hexdigest(), 'user', 0, 0, 1),
        ('diana', 'diana@example.com', hashlib.sha256('diana123'.encode()).hexdigest(), 'admin', 1, 1, 1),
        ('eve', 'eve@example.com', hashlib.sha256('eve123'.encode()).hexdigest(), 'user', 0, 0, 1),
        ('frank', 'frank@example.com', hashlib.sha256('frank123'.encode()).hexdigest(), 'user', 0, 1, 1),
        ('grace', 'grace@example.com', hashlib.sha256('grace123'.encode()).hexdigest(), 'user', 0, 0, 1),
        ('henry', 'henry@example.com', hashlib.sha256('henry123'.encode()).hexdigest(), 'admin', 1, 1, 1),
        ('isabella', 'isabella@example.com', hashlib.sha256('isabella123'.encode()).hexdigest(), 'user', 0, 0, 1),
        ('jack', 'jack@example.com', hashlib.sha256('jack123'.encode()).hexdigest(), 'user', 0, 1, 1)
    ]
    
    try:
        conn = sqlite3.connect('primary.db')
        cursor = conn.cursor()
        
        for user in users:
            cursor.execute('''
                INSERT INTO users (username, email, password_hash, role, created_at,
                can_manage_users, can_resolve_conflicts, can_view_reports, sync_version)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (user[0], user[1], user[2], user[3], datetime.utcnow().isoformat(),
                  user[4], user[5], user[6], 0))
        
        conn.commit()
        conn.close()
        logger.info(f"✅ Created {len(users)} test users")
        
    except Exception as e:
        logger.error(f"Error creating test users: {e}")

def create_test_authors():
    """Create test authors with conflicts"""
    authors = [
        # Format: (name, nationality, birth_year, biography)
        ('J.K. Rowling', 'British', 1965, 'Author of Harry Potter series'),
        ('George Orwell', 'British', 1903, 'Author of 1984 and Animal Farm'),
        ('Harper Lee', 'American', 1926, 'Author of To Kill a Mockingbird'),
        ('J.R.R. Tolkien', 'British', 1892, 'Author of The Lord of the Rings'),
        ('Agatha Christie', 'British', 1890, 'Queen of Crime fiction'),
        ('Stephen King', 'American', 1947, 'Master of horror fiction'),
        ('Jane Austen', 'British', 1775, 'Classic English novelist'),
        ('Mark Twain', 'American', 1835, 'Author of Adventures of Huckleberry Finn'),
        ('Ernest Hemingway', 'American', 1899, 'Nobel Prize-winning author'),
        ('Leo Tolstoy', 'Russian', 1828, 'Author of War and Peace')
    ]
    
    try:
        conn = sqlite3.connect('primary.db')
        cursor = conn.cursor()
        
        for author in authors:
            cursor.execute('''
                INSERT INTO authors (name, nationality, birth_year, biography, sync_version)
                VALUES (?, ?, ?, ?, ?)
            ''', (author[0], author[1], author[2], author[3], 0))
        
        conn.commit()
        conn.close()
        logger.info(f"✅ Created {len(authors)} test authors")
        
    except Exception as e:
        logger.error(f"Error creating test authors: {e}")

def create_test_sections():
    """Create test sections with conflicts"""
    sections = [
        # Format: (name, description, floor, room_number)
        ('Fiction', 'General fiction books', 1, '101'),
        ('Science Fiction', 'Sci-Fi and fantasy books', 2, '201'),
        ('Mystery', 'Mystery and thriller books', 1, '102'),
        ('Biography', 'Biographies and memoirs', 3, '301'),
        ('Technology', 'Computer science and tech books', 2, '202'),
        ('History', 'Historical books and documents', 1, '103'),
        ('Science', 'Scientific literature', 3, '302'),
        ('Art', 'Art and design books', 2, '203'),
        ('Children', 'Children\'s literature', 1, '104'),
        ('Reference', 'Reference materials and encyclopedias', 3, '303')
    ]
    
    try:
        conn = sqlite3.connect('primary.db')
        cursor = conn.cursor()
        
        for section in sections:
            cursor.execute('''
                INSERT INTO sections (name, description, floor, room_number, sync_version)
                VALUES (?, ?, ?, ?, ?)
            ''', (section[0], section[1], section[2], section[3], 0))
        
        conn.commit()
        conn.close()
        logger.info(f"✅ Created {len(sections)} test sections")
        
    except Exception as e:
        logger.error(f"Error creating test sections: {e}")

def create_test_books():
    """Create test books with conflicts"""
    books = [
        # Format: (isbn, title, author_id, section_id, published_year, publisher, copies_available, price)
        ('9780747532743', 'Harry Potter and the Philosopher\'s Stone', 1, 1, 1997, 'Bloomsbury', 5, 24.99),
        ('9780451524935', '1984', 2, 2, 1949, 'Secker & Warburg', 3, 9.99),
        ('9780061120084', 'To Kill a Mockingbird', 3, 1, 1960, 'J.B. Lippincott', 2, 14.99),
        ('9780547928227', 'The Hobbit', 4, 2, 1937, 'George Allen & Unwin', 4, 19.99),
        ('9780007119318', 'Murder on the Orient Express', 5, 3, 1934, 'Collins Crime Club', 3, 12.99),
        ('9780345806789', 'The Shining', 6, 3, 1977, 'Doubleday', 2, 15.99),
        ('9780141439518', 'Pride and Prejudice', 7, 1, 1813, 'T. Egerton', 6, 8.99),
        ('9780486280615', 'Adventures of Huckleberry Finn', 8, 1, 1884, 'Chatto & Windus', 4, 7.99),
        ('9780684801223', 'The Old Man and the Sea', 9, 1, 1952, 'Charles Scribner\'s Sons', 3, 10.99),
        ('9780198800545', 'War and Peace', 10, 6, 1869, 'The Russian Messenger', 2, 29.99)
    ]
    
    try:
        conn = sqlite3.connect('primary.db')
        cursor = conn.cursor()
        
        for book in books:
            cursor.execute('''
                INSERT INTO books (isbn, title, author_id, section_id, published_year, 
                publisher, copies_available, price, sync_version)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (book[0], book[1], book[2], book[3], book[4], book[5], book[6], book[7], 0))
        
        conn.commit()
        conn.close()
        logger.info(f"✅ Created {len(books)} test books")
        
    except Exception as e:
        logger.error(f"Error creating test books: {e}")

def create_test_borrow_records():
    """Create test borrow records with conflicts"""
    borrow_records = []
    base_date = datetime.utcnow()
    
    # Create 10 borrow records
    for i in range(1, 11):
        user_id = i if i <= 10 else 1
        book_id = i if i <= 10 else 1
        borrow_date = base_date - timedelta(days=random.randint(1, 30))
        due_date = borrow_date + timedelta(days=14)
        return_date = borrow_date + timedelta(days=random.randint(1, 14)) if random.choice([True, False]) else None
        status = 'returned' if return_date else 'borrowed'
        fine_amount = random.uniform(0, 5.0) if status == 'returned' and random.choice([True, False]) else 0.0
        
        borrow_records.append((
            user_id, book_id, borrow_date.isoformat(), 
            due_date.isoformat(), 
            return_date.isoformat() if return_date else None,
            status, fine_amount
        ))
    
    try:
        conn = sqlite3.connect('primary.db')
        cursor = conn.cursor()
        
        for record in borrow_records:
            cursor.execute('''
                INSERT INTO borrow_records (user_id, book_id, borrow_date, due_date, 
                return_date, status, fine_amount, sync_version)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ''', (record[0], record[1], record[2], record[3], record[4], record[5], record[6], 0))
        
        conn.commit()
        conn.close()
        logger.info(f"✅ Created {len(borrow_records)} test borrow records")
        
    except Exception as e:
        logger.error(f"Error creating test borrow records: {e}")

def create_test_sync_metadata():
    """Create test sync metadata"""
    sync_entries = []
    base_date = datetime.utcnow()
    
    # Create 10 sync metadata entries
    for i in range(10):
        sync_timestamp = base_date - timedelta(hours=i*2)
        changes_synced = random.randint(0, 50)
        conflicts_detected = random.randint(0, 10)
        status = 'completed' if random.random() > 0.1 else 'failed'
        
        sync_entries.append((
            sync_timestamp.isoformat(), changes_synced, conflicts_detected, status
        ))
    
    try:
        conn = sqlite3.connect('primary.db')
        cursor = conn.cursor()
        
        for entry in sync_entries:
            cursor.execute('''
                INSERT INTO sync_metadata (sync_timestamp, changes_synced, conflicts_detected, status)
                VALUES (?, ?, ?, ?)
            ''', entry)
        
        conn.commit()
        conn.close()
        logger.info(f"✅ Created {len(sync_entries)} test sync metadata entries")
        
    except Exception as e:
        logger.error(f"Error creating test sync metadata: {e}")

def create_test_data_conflicts():
    """Create test data conflicts"""
    conflicts = []
    
    # Create conflicts for different tables
    conflict_types = [
        {
            'table': 'authors',
            'record_id': 1,
            'database_source': 'mysql',
            'conflict_type': 'data_mismatch',
            'data': {
                'name': 'J.K. Rowling',
                'nationality': 'British',  # Primary has 'British'
                'mysql_nationality': 'Scottish',  # MySQL has 'Scottish'
                'birth_year': 1965
            }
        },
        {
            'table': 'books',
            'record_id': 1,
            'database_source': 'mysql',
            'conflict_type': 'data_mismatch',
            'data': {
                'title': 'Harry Potter and the Philosopher\'s Stone',
                'price': 24.99,  # Primary has 24.99
                'mysql_price': 29.99,  # MySQL has 29.99
                'copies_available': 5
            }
        },
        {
            'table': 'books',
            'record_id': 2,
            'database_source': 'postgresql',
            'conflict_type': 'data_mismatch',
            'data': {
                'title': '1984',
                'price': 9.99,  # Primary has 9.99
                'postgres_price': 12.99,  # PostgreSQL has 12.99
                'copies_available': 3
            }
        },
        {
            'table': 'authors',
            'record_id': 6,
            'database_source': 'postgresql',
            'conflict_type': 'missing_record',
            'data': {
                'primary_exists': True,
                'postgres_exists': False,
                'author_name': 'Stephen King'
            }
        },
        {
            'table': 'sections',
            'record_id': 3,
            'database_source': 'mysql',
            'conflict_type': 'data_mismatch',
            'data': {
                'name': 'Mystery',
                'description': 'Mystery and thriller books',
                'floor': 1,
                'mysql_floor': 2,  # Different floor number
                'room_number': '102'
            }
        }
    ]
    
    try:
        conn = sqlite3.connect('primary.db')
        cursor = conn.cursor()
        
        for i, conflict in enumerate(conflict_types, 1):
            detected_at = datetime.utcnow() - timedelta(days=i)
            
            cursor.execute('''
                INSERT INTO data_conflicts (table_name, record_id, database_source, 
                conflict_data, detected_at, resolved)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (
                conflict['table'],
                conflict['record_id'],
                conflict['database_source'],
                json.dumps(conflict['data']),
                detected_at.isoformat(),
                False  # Not resolved
            ))
        
        conn.commit()
        conn.close()
        logger.info(f"✅ Created {len(conflicts)} test data conflicts")
        
    except Exception as e:
        logger.error(f"Error creating test data conflicts: {e}")

def seed_test_data():
    """Seed all test data"""
    logger.info("🌱 Seeding test data...")
    
    create_admin_user()
    create_test_users()
    create_test_authors()
    create_test_sections()
    create_test_books()
    create_test_borrow_records()
    create_test_sync_metadata()
    create_test_data_conflicts()
    
    logger.info("✅ All test data seeded successfully")

def create_conflicts_in_secondary_databases():
    """Create actual conflicts in secondary databases"""
    logger.info("⚡ Creating conflicts in secondary databases...")
    
    try:
        # 1. Create conflicts in MySQL database
        mysql_conn = sqlite3.connect('mysql_sim.db')
        mysql_cursor = mysql_conn.cursor()
        
        # Modify author nationality differently
        mysql_cursor.execute("UPDATE authors SET nationality = 'Scottish' WHERE id = 1")
        mysql_cursor.execute("UPDATE authors SET birth_year = 1966 WHERE id = 1")
        
        # Modify book price differently
        mysql_cursor.execute("UPDATE books SET price = 29.99 WHERE id = 1")
        mysql_cursor.execute("UPDATE books SET copies_available = 3 WHERE id = 1")
        
        # Modify section floor differently
        mysql_cursor.execute("UPDATE sections SET floor = 2 WHERE id = 3")
        
        # Delete a record that exists in primary
        mysql_cursor.execute("DELETE FROM authors WHERE id = 6")
        
        mysql_conn.commit()
        mysql_conn.close()
        
        # 2. Create different conflicts in PostgreSQL database
        postgres_conn = sqlite3.connect('postgres_sim.db')
        postgres_cursor = postgres_conn.cursor()
        
        # Modify book price differently
        postgres_cursor.execute("UPDATE books SET price = 12.99 WHERE id = 2")
        postgres_cursor.execute("UPDATE books SET publisher = 'Penguin Books' WHERE id = 2")
        
        # Modify user role differently
        postgres_cursor.execute("UPDATE users SET role = 'admin' WHERE id = 2")
        
        # Add a record that doesn't exist in primary
        postgres_cursor.execute('''
            INSERT INTO authors (name, nationality, birth_year, biography, sync_version)
            VALUES ('Test Author PostgreSQL', 'Canadian', 1980, 'Test author only in PostgreSQL', 0)
        ''')
        
        postgres_conn.commit()
        postgres_conn.close()
        
        logger.info("✅ Created conflicts in secondary databases:")
        logger.info("   MySQL:")
        logger.info("     - Author 1: nationality='Scottish' (vs 'British'), birth_year=1966 (vs 1965)")
        logger.info("     - Book 1: price=29.99 (vs 24.99), copies=3 (vs 5)")
        logger.info("     - Section 3: floor=2 (vs 1)")
        logger.info("     - Author 6: Deleted (vs exists in primary)")
        logger.info("   PostgreSQL:")
        logger.info("     - Book 2: price=12.99 (vs 9.99), publisher='Penguin Books' (vs 'Secker & Warburg')")
        logger.info("     - User 2: role='admin' (vs 'user')")
        logger.info("     - Added new author only in PostgreSQL")
        
    except Exception as e:
        logger.error(f"Error creating conflicts in secondary databases: {e}")

def copy_data_to_secondary_databases():
    """Copy data from primary to secondary databases"""
    logger.info("📋 Copying data to secondary databases...")
    
    try:
        # First, get schema from primary
        primary_conn = sqlite3.connect('primary.db')
        primary_cursor = primary_conn.cursor()
        
        # Get all tables
        primary_cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
        tables = [row[0] for row in primary_cursor.fetchall()]
        
        for db_name in ['mysql_sim.db', 'postgres_sim.db']:
            logger.info(f"  Processing {db_name}...")
            secondary_conn = sqlite3.connect(db_name)
            secondary_cursor = secondary_conn.cursor()
            
            for table in tables:
                # Get create statement from primary
                primary_cursor.execute(f"SELECT sql FROM sqlite_master WHERE type='table' AND name='{table}'")
                create_sql = primary_cursor.fetchone()
                
                if create_sql:
                    # Drop table if exists and recreate
                    secondary_cursor.execute(f"DROP TABLE IF EXISTS {table}")
                    secondary_cursor.execute(create_sql[0])
                    
                    # Copy data
                    primary_cursor.execute(f"SELECT * FROM {table}")
                    rows = primary_cursor.fetchall()
                    
                    if rows:
                        # Get column names
                        primary_cursor.execute(f"PRAGMA table_info({table})")
                        columns = primary_cursor.fetchall()
                        col_names = [col[1] for col in columns]
                        
                        placeholders = ', '.join(['?'] * len(col_names))
                        col_names_str = ', '.join(col_names)
                        
                        for row in rows:
                            secondary_cursor.execute(
                                f"INSERT INTO {table} ({col_names_str}) VALUES ({placeholders})",
                                row
                            )
            
            secondary_conn.commit()
            secondary_conn.close()
        
        primary_conn.close()
        logger.info("✅ Data copied to secondary databases")
        
    except Exception as e:
        logger.error(f"Error copying data to secondary databases: {e}")

def initialize_databases():
    """Initialize all databases with schema"""
    try:
        # Import here to avoid circular imports
        from app import create_app, db
        
        # Create Flask app
        app = create_app()
        
        # Set BASEDIR in config
        BASE_DIR = os.path.dirname(os.path.abspath(__file__))
        app.config['BASEDIR'] = BASE_DIR
        
        with app.app_context():
            # Import models here to ensure app context
            from app.models import User, Author, Section, Book, BorrowRecord, SyncMetadata, DataConflict
            
            # Create tables in primary database
            db.create_all()
            logger.info("✅ Primary database schema created")
            
            # Seed all test data
            seed_test_data()
            
            # Create secondary databases
            db_files = ['mysql_sim.db', 'postgres_sim.db']
            for db_file in db_files:
                db_path = os.path.join(BASE_DIR, db_file)
                if not os.path.exists(db_path):
                    conn = sqlite3.connect(db_path)
                    conn.close()
                    logger.info(f"✅ Created {db_file}")
            
            # Copy data to secondary databases
            copy_data_to_secondary_databases()
            
            # Create conflicts in secondary databases
            create_conflicts_in_secondary_databases()
            
        return app
        
    except Exception as e:
        logger.error(f"Error initializing databases: {e}")
        import traceback
        traceback.print_exc()
        return None

def run_system():
    """Start the Flask application"""
    try:
        from app import create_app
        from app.syncer import init_syncer
        from app.detector import init_detector
        
        # Create app
        app = create_app()
        app.config['BASEDIR'] = os.path.dirname(os.path.abspath(__file__))
        
        # Initialize syncer
        syncer = init_syncer(app)
        app.real_time_syncer = syncer
        
        # Initialize detector
        detector = init_detector(app)
        app.conflict_detector = detector
        
        logger.info("=" * 60)
        logger.info("🚀 Multi-DB Sync System Starting")
        logger.info("=" * 60)
        logger.info(f"📊 Primary DB: {os.path.join(app.config['BASEDIR'], 'primary.db')}")
        logger.info(f"📊 MySQL Sim: {os.path.join(app.config['BASEDIR'], 'mysql_sim.db')}")
        logger.info(f"📊 PostgreSQL Sim: {os.path.join(app.config['BASEDIR'], 'postgres_sim.db')}")
        logger.info("🌐 Web Interface: http://127.0.0.1:5000")
        logger.info("👤 Admin Login: admin / admin123")
        logger.info("📈 Test conflicts have been pre-created")
        logger.info("=" * 60)
        
        # Start Flask
        app.run(host="0.0.0.0", port=5000, debug=True, use_reloader=False)
        
    except Exception as e:
        logger.error(f"Error running system: {e}")
        import traceback
        traceback.print_exc()

def main():
    """Main entry point"""
    # Setup logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    logger.info("🚀 Starting Multi-DB Sync System Setup")
    
    # Step 1: Delete old databases
    logger.info("🧹 Cleaning up old databases...")
    delete_old_databases()
    time.sleep(1)
    
    # Step 2: Initialize databases
    logger.info("🗄️ Initializing databases...")
    app = initialize_databases()
    
    if not app:
        logger.error("❌ Failed to initialize databases")
        sys.exit(1)
    
    # Step 3: Run the system
    logger.info("▶️ Starting the system...")
    run_system()

if __name__ == "__main__":
    main()
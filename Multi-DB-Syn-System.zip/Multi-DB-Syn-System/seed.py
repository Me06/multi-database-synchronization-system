from app import create_app, db
from app.models import *
from datetime import datetime, timedelta
import random

app = create_app()

def seed():
    with app.app_context():
        print("🛠️ Creating tables if they do not exist...")
        db.create_all()

        print("🌱 Seeding PRIMARY database with demo data")

        # ---------- CLEAR ----------
        for model in [DataConflict, SyncMetadata, BorrowRecord, Book, Author, Section, User]:
            db.session.query(model).delete()
        db.session.commit()

        # ---------- USERS ----------
        users = []
        for i in range(1, 11):
            u = User(
                username="admin" if i==1 else f"user{i}",
                email=f"user{i}@demo.com",
                role="admin" if i==1 else "user",
                last_login=datetime.utcnow(),
                sync_version=i,
                can_manage_users=True if i==1 else False,
                can_resolve_conflicts=True if i==1 else False,
                can_view_reports=True
            )
            u.set_password("admin123" if i==1 else "user123")
            users.append(u)

        # ---------- AUTHORS ----------
        authors = [Author(name=f"Author {i}", nationality=random.choice(["USA","UK","France"]), birth_year=1960+i, biography=f"Biography {i}", sync_version=i) for i in range(1,11)]

        # ---------- SECTIONS ----------
        sections = [Section(name=f"Section {i}", description=f"Section description {i}", floor=random.randint(1,3), room_number=f"R-{i}", sync_version=i) for i in range(1,11)]

        # ---------- BOOKS ----------
        books = [Book(isbn=f"97800000000{i}", title=f"Book {i}", author_id=i, section_id=i, published_year=2000+i, publisher="Demo Publisher", copies_available=random.randint(1,10), price=round(random.uniform(50,200),2), sync_version=i) for i in range(1,11)]

        # ---------- BORROWS ----------
        borrows = [BorrowRecord(user_id=i, book_id=i, borrow_date=datetime.utcnow()-timedelta(days=3), due_date=datetime.utcnow()+timedelta(days=7), status="borrowed", fine_amount=0.0, sync_version=i) for i in range(1,11)]

        # ---------- SYNC METADATA ----------
        sync_meta = [SyncMetadata(changes_synced=random.randint(5,20), conflicts_detected=random.randint(0,3), status="completed") for _ in range(10)]

        db.session.add_all(users + authors + sections + books + borrows + sync_meta)
        db.session.commit()
        print("✅ Seed completed successfully")

if __name__ == "__main__":
    seed()

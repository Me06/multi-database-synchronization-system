#!/usr/bin/env python3
"""
Simple run script for Multi-DB Sync System
"""
import logging
import os

def main():
    # Setup logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    logger = logging.getLogger("MultiDB")
    
    try:
        # Import and create app
        from app import create_app
        from app.syncer import init_syncer
        
        app = create_app()
        
        # Set base directory
        BASE_DIR = os.path.dirname(os.path.abspath(__file__))
        app.config['BASEDIR'] = BASE_DIR
        
        # Initialize syncer
        syncer = init_syncer(app)
        app.real_time_syncer = syncer
        
        # Display startup info
        print("=" * 60)
        print("🚀 Multi-DB Sync System")
        print("=" * 60)
        print(f"📊 Primary DB: {os.path.join(BASE_DIR, 'primary.db')}")
        print(f"📊 MySQL Sim: {os.path.join(BASE_DIR, 'mysql_sim.db')}")
        print(f"📊 PostgreSQL Sim: {os.path.join(BASE_DIR, 'postgres_sim.db')}")
        print("🌐 Web Interface: http://127.0.0.1:5000")
        print("👤 Admin Login: admin / admin123")
        print("=" * 60)
        
        # Start server
        app.run(host="0.0.0.0", port=5000, debug=True, use_reloader=False)
        
    except Exception as e:
        logger.error(f"Error starting system: {e}")
        import traceback
        traceback.print_exc()
        input("Press Enter to exit...")

if __name__ == "__main__":
    main()